FILE_NAMING_RULE: c_file.c
DESCRIPTION_START
This is the default template used for the creation of C files.
Template supplied by Mentor Graphics.
DESCRIPTION_END
/*
 * Created:
 *         by - %(user).%(group) (%(host))
 *         at - %(time) %(date)
 *
 * using Mentor Graphics HDL Designer(TM) %(version)
 */

